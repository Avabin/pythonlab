import time
import os
def calculate():
    time.sleep(1)
    for i in range(1, 10):
        pass
    return os.urandom(16)

print(calculate())
